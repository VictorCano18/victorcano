import React from "react";
import Navbar from "../components/Navbar/Navbar";
import Charts from "../components/Charts/Charts";

export default function Productivity() {
  return (
    <div>
      <Navbar />
      <Charts />
    </div>
  );
}
