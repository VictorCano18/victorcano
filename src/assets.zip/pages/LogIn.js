import React from "react";
import LoginPage from "../components/Register/LogIn/LogIn";
import "../index.css";

export default function LogIn() {
  return (
    <div>
      <LoginPage />
    </div>
  );
}
