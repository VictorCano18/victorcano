import React from "react";
import Navbar from "../components/Navbar/Navbar";
import Boards from "../components/Boards/Boards";
import "../index.css";

export default function Home() {
  return (
    <div>
      <Navbar />
      <Boards />
    </div>
  );
}
