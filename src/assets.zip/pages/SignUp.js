import React from "react";
import SignUpPage from "../components/Register/SignUp/SignUp";
import "../index.css";

export default function SignUp() {
  return (
    <div>
      <SignUpPage />
    </div>
  );
}
