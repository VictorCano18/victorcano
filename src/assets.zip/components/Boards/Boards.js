import React, { useContext, useState, useEffect } from "react";
import "./Boards.css";
import { api } from "../../lib/request";
import swal from "sweetalert";
import { UserContext } from "../../context/UserContext";
import Modal from "react-modal";
import Loading from "../../assets/img/loading.gif";
import { useHistory } from "react-router-dom";

/**
 * Constant to create a new Boards component.
 * @type {Component}
 */
const Boards = () => {
  /**
   * History variable to navigate among different routes.
   * @let
   */
  let history = useHistory();

  /**
   * Context Constant to use the UserContext in the component to set the data to use
   * if a board it is been clicked
   * @type {array}
   */
  const { setProductivity, setKeys } = useContext(UserContext);

  /**
   * Mutators to set and get boards, userName of modalIsOpen data.
   * @type {string}
   */
  const [boards, setBoards] = useState([]);
  const [userName, setUserName] = useState("");
  const [modalIsOpen, setIsOpen] = useState(false);

  /**
   * Open the loader modal when the quote button was clicked.
   * @function
   */
  const openModal = () => {
    setIsOpen(true);
  };

  /**
   * Close the loader modal when call to quote ends.
   * @function
   */
  const closeModal = () => {
    setIsOpen(false);
  };

  /**
   * Display a popup for the user to type his board name. If it pass all the checks,
   * it will be save in the data variable. The'jira/board' call will be using with the
   * board's name of the user and a popup will be display to say that the adding was successfuly.
   * If not, an error popup will be display if the board already exists or an internal error.
   * @function
   */
  const newBoard = () => {
    swal("Board name", {
      content: "input",
    }).then((name) => {
      if (name === "") {
        swal("Required field", "Enter the board name", "warning");
      } else {
        let data = { name: name };
        api
          .post("jira/board", data)
          .then(() => {
            swal("New board added successfully", "", "success");
            getJiraData();
          })
          .catch((error) => {
            const { name } = error.response.data;
            switch (name[0]) {
              case "Tablero Jira with this nombre tablero already exists.":
                swal("This board already exists", "", "warning");
                break;
              default:
                swal("Internal error", "Try again", "error");
            }
            setProductivity([]);
          });
      }
    });
  };

  /**
   * It calls the 'jira/board' call when the Boards page reder to display all the user's board.
   * If the user do not have, it display a pop up that says that you do not habe any boards yet.
   * @function
   */
  const getJiraData = async () => {
    await api
      .get("jira/board")
      .then((res) => {
        setBoards(res.data);
        setUserName(res.data[0].user_name.toUpperCase());
      })
      .catch(() => {
        swal(
          "You don´t have any boards yet",
          "Add a board and try again",
          "warning"
        );
      });
  };

  /**
   * It set the board's name with the data received in the arguments. Then a modal will be display 
   * while the call load.
   * The call that it use is 'jira/request'. it sends the board´s name and if it receive a status 200
   * the productivity UseContext varible will be set with the return information of the call, besides, 
   * on the keys varible will use a map to iterate over the issues (from the jira's data) and save the
   * information on the variable key. Finally, the keys UserContext varible will be set with the
   * keys data and redirects the user to the productivity page.
   * If the call return a 400 status, a pop up will be display for: Not data found or internal error.
   * @function
   */
  const getBoardData = async (name) => {
    let key = [];
    const data = {
      board: name,
    };
    openModal();
    await api
      .post("jira/request", data)
      .then((res) => {
        setProductivity(res.data);

        let keys = res.data.data.map((issue) => {
          key = Object.keys(issue);
          return key[3];
        });

        setKeys(keys);
        history.push("/productivity");
      })
      .catch((error) => {
        const { Error } = error.response.data;
        switch (Error) {
          case "Not data found":
            swal(
              "No data found to load",
              "Select another board and try again",
              "warning"
            );
            break;
          default:
            swal("Internal error", "Try again", "error");
            console.error(error);
            this.setState({ error: true });
        }
        setProductivity([]);
      });
    closeModal();
  };

  useEffect(() => {
    getJiraData();
  }, []);

  /**
   * Returns the HTML to render the Boards component.
   * @return {const} Boards
   */
  return (
    <div className="container col-12">
      <div className="row d-flex justify-content-center align-items-center">
        <div id="jiraWelcomeBlock" className="col-12 text-left mb-5 pt-3 pb-3">
          <h2>WELCOME, {userName}</h2>
        </div>
        <div
          className="col-12 col-sm-8 col-xl-6 rounded"
          id="jiraBoardBackground"
        >
          <h2 id="jiraBoardTitle" className="text-center mt-2">
            Boards
          </h2>
          <table className="table table-hover table-responsive-sm table-hover d-flex flex-column justify-content-center align-items-center">
            <thead>
              <tr className="text-center">
                <th scope="col">Board Name</th>
              </tr>
            </thead>
            <tbody className="text-center">
              {boards.map((data, id) => (
                <tr key={id}>
                  <td onClick={() => getBoardData(data.name)}>{data.name}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <div className="row d-flex justify-content-center align-items-center mt-5 mb-5">
        <div className="col-12 col-sm-4 col-lg-3">
          <button
            id="btnNewBoard"
            className="btn btn-block btn-danger btn-lg"
            onClick={(e) => newBoard(e)}
          >
            Add Board
          </button>
        </div>
      </div>

      <div id="loading">
        <Modal
          ariaHideApp={false}
          isOpen={modalIsOpen}
          onRequestClose={closeModal}
          contentLabel="Modal"
          id="loadingModal"
          className="d-flex justify-content-center align-items-center"
        >
          <img
            src={Loading}
            alt="loading"
            id="loading"
            className="img-fluid"
          ></img>
        </Modal>
      </div>
    </div>
  );
};

export default Boards;
