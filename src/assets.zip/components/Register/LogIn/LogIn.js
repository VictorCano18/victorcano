import React, { Component } from "react";
import "./LogIn.css";

import { api } from "../../../lib/request";
import { Link } from "react-router-dom";

import HSBCLogo from "../../../assets/img/hsbcLogo.png";
import GrayBackground from "../../../assets/img/grayBackground.jpg";

import swal from "sweetalert";

/**
 * Class to create a new LogIn component for an user with a account previously created.
 * @class LogIn
 */
class LogIn extends Component {
  /**
   * Add the state with the user's credentials in this.state.user. Also includes the
   * modal and the error controls.
   * @constructor
   */
  constructor(props) {
    super(props);
    this.state = {
      user: {
        email: "",
        password: "",
      },
      modal: false,
      error: false,
    };

    this.login = this.login.bind(this);
    this.handleEmail = this.handleEmail.bind(this);
    this.handlePassword = this.handlePassword.bind(this);
  }

  componentDidMount() {
    document.getElementById("singInForm").reset();
  }

  /**
   * Sets the user's email in the email variable.
   * @function
   */
  handleEmail(event) {
    const email = event.target.value;
    this.setState((prevState) => ({
      ...prevState,
      user: {
        ...prevState.user,
        email,
      },
    }));
  }

  /**
   * Sets the user's password in the email variable.
   * @function
   */
  handlePassword(event) {
    const password = event.target.value;
    this.setState((prevState) => ({
      ...prevState,
      user: {
        ...prevState.user,
        password,
      },
    }));
  }

  /**
   * Checks that the email and password fields are not empty, if so, it calls the 'auth' call with the credentials
   * previously entry by the user. If the call returns a 200 status, the token constant will be the result of that and
   * the local storage in the 'jwt' variable, will be set with the token, and the user will be redirect to the home page.
   * On the other hand, if the call return a 400 status, it will be for: credentials are not valid or internal error.
   * @function
   */
  async login(event) {
    event.preventDefault();
    if (this.state.user.email === "") {
      swal("Required field", "Enter your email", "warning");
    } else if (this.state.user.password === "") {
      swal("Required field", "Enter your password", "warning");
    } else {
      api
        .post("auth", this.state.user, false)
        .then((res) => {
          const { token } = res.data;
          window.localStorage.setItem("jwt", token);
          window.location.href = "/home";
        })
        .catch((error) => {
          const { non_field_errors } = error.response.data;
          switch (non_field_errors[0]) {
            case "credentials are not valid":
              swal("Invalid email or password", " ", "error");
              break;
            default:
              swal("Internal error", "Try again", "error");
              console.error(error);
              this.setState({ error: true });
          }
        });
    }
  }

  render() {
    /**
     * Returns the HTML to render the LogIn component.
     * @return {class} LogIn
     */
    return (
      <div className="container ml-0 mr-0">
        <div className="row d-flex justify-content-center align-items-center">
          <div
            id="grayLogInSquare"
            className="col-12 col-md-6 col-lg-7 d-none d-sm-block"
          >
            <img
              src={GrayBackground}
              id="grayBackground"
              alt="GrayBackground"
              className="img-fluid"
            />
          </div>
          <div className="col-12 col-md-6 col-lg-5 pl-2 pl-sm-5">
            <div id="logInTitleSesion" className="col-12 pb-4 pt-3 text-left">
              <img
                src={HSBCLogo}
                id="hsbcLogo"
                alt="hsbcLogo"
                className="img-fluid mt-2 mb-5"
              />
              <p className="mt-5">Log In</p>
              <h6>Enter you login and password</h6>
            </div>
            <div id="logInForm" className="col-12">
              <form
                id="singInForm"
                className="mt-1 text-left"
                onSubmit={this.login}
              >
                <label>Email</label>
                <input
                  className="LogIn mt-1 mb-5"
                  name="email"
                  id="email"
                  type="email"
                  onBlur={(e) => this.handleEmail(e)}
                />
                <label>Password</label>
                <input
                  className="LogIn mt-1 mb-5"
                  name="password"
                  id="password"
                  type="password"
                  autoComplete="true"
                  onChange={(e) => this.handlePassword(e)}
                />

                <div className="d-flex justify-content-start">
                  <input
                    disabled={this.isSubmitting}
                    type="submit"
                    id="btnSesion"
                    value="Log In"
                    className="btn btn-block"
                  />
                </div>
              </form>
              <div className="d-flex justify-content-start">
                <Link
                  to="/signUp"
                  id="btnInicio"
                  className="btn btn-md btn-outline-secondary text-left"
                  role="button"
                >
                  Sign Up
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default LogIn;
