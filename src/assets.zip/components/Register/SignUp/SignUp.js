import React, { Component } from "react";
import "./SignUp.css";

import { api } from "../../../lib/request";
import { Link } from "react-router-dom";

import HSBCLogo from "../../../assets/img/hsbcLogo.png";
import GrayBackground from "../../../assets/img/grayBackground.jpg";
import ReactTooltip from "react-tooltip";

import swal from "sweetalert";

/**
 * Class to create a new SignUp component for an user to create his account.
 * @class SignUp
 */
class SignUp extends Component {
  /**
   * Add the state with the user's data in this.state.user. Also includes the
   * modal and the error controls.
   * @constructor
   */
  constructor(props) {
    super(props);
    this.state = {
      user: {
        user_name: "",
        token_jira: "",
        email: "",
        password: "",
      },
      modal: false,
      error: false,
    };

    this.signUp = this.signUp.bind(this);
    this.handleUsername = this.handleUsername.bind(this);
    this.handleToken = this.handleToken.bind(this);
    this.handleEmail = this.handleEmail.bind(this);
    this.handlePassword = this.handlePassword.bind(this);
  }

  componentDidMount() {
    document.getElementById("singInForm").reset();
  }

  /**
   * Sets the user name in the username variable.
   * @function
   */
  handleUsername(event) {
    const user_name = event.target.value;
    this.setState((prevState) => ({
      ...prevState,
      user: {
        ...prevState.user,
        user_name,
      },
    }));
  }

  /**
   * Sets the user's token in the token variable.
   * @function
   */
  handleToken(event) {
    const token_jira = event.target.value;
    this.setState((prevState) => ({
      ...prevState,
      user: {
        ...prevState.user,
        token_jira,
      },
    }));
  }

  /**
   * Sets the user's email in the email variable.
   * @function
   */
  handleEmail(event) {
    const email = event.target.value;
    this.setState((prevState) => ({
      ...prevState,
      user: {
        ...prevState.user,
        email,
      },
    }));
  }

  /**
   * Sets the user's password in the email variable.
   * @function
   */
  handlePassword(event) {
    const password = event.target.value;
    this.setState((prevState) => ({
      ...prevState,
      user: {
        ...prevState.user,
        password,
      },
    }));
  }

  /**
   * Checks that the email, password, user name and jira's token fields are not empty, if so, it calls the 'users/create'
   * call with the user's data previously entry. If the call returns a 200 status, the token constant will be
   * the result of that and the local storage in the 'jwt' variable, will be set with the token, a pop up will be show
   * to notice the user that his account has been created successfuly and the user will be redirect
   * to the LogIn page. On the other hand, if the call return a 400 status, it will be for: This password is too short. It must
   * contain at least 8 characters or internal error.
   * @function
   */
  async signUp(event) {
    event.preventDefault();
    if (this.state.user.user_name === "") {
      swal("Required field", "Enter your username", "warning");
    } else if (this.state.user.token_jira === "") {
      swal("Required field", "Enter your Jira token", "warning");
    } else if (this.state.user.email === "") {
      swal("Required field", "Enter your email", "warning");
    } else if (this.state.user.password === "") {
      swal("Required field", "Enter your password", "warning");
    } else {
      api
        .post("users/create", this.state.user, false)
        .then((res) => {
          const { token } = res.data;
          window.localStorage.setItem("jwt", token);
          swal("Account created successfully", "", "success");
          setTimeout(function () {
            window.location.href = "./";
          }, 2000);
        })
        .catch((error) => {
          const { password } = error.response.data;
          switch (password[0]) {
            case "This password is too short. It must contain at least 8 characters.":
              swal(
                "Your password is too short",
                "It must contain at least 8 characters",
                "warning"
              );
              break;
            default:
              swal("Internal error", "Try again", "error");
              console.error(error);
              this.setState({ error: true });
          }
        });
    }
  }

  render() {
    /**
     * Returns the HTML to render the SignUp component.
     * @return {class} SignUp
     */
    return (
      <div className="container ml-0">
        <div className="row d-flex justify-content-center align-items-center">
          <div
            id="grayLogInSquare"
            className="col-12 col-md-6 col-lg-7 d-none d-sm-block"
          >
            <img
              src={GrayBackground}
              id="grayBackground"
              alt="GrayBackground"
              className="img-fluid"
            />
          </div>
          <div className="col-12 col-md-6 col-lg-5 pl-2 pl-sm-5">
            <div id="logInTitleSesion" className="col-12 pb-4 pt-3 text-left">
              <img
                src={HSBCLogo}
                id="hsbcLogo"
                alt="hsbcLogo"
                className="img-fluid mt-2"
              />
              <p className="mt-5">Sign Up</p>
            </div>
            <div id="logInForm" className="col-12">
              <form
                id="singInForm"
                className="text-left"
                onSubmit={this.signUp}
              >
                <label>Username</label>
                <input
                  className="LogIn mt-1 mb-2"
                  name="username"
                  id="username"
                  type="text"
                  autoComplete="true"
                  onChange={(e) => this.handleUsername(e)}
                />
                <label data-tip data-for="registerTip1">
                  Jira Token <i className="fas fa-info-circle pl-2"></i>
                </label>

                <ReactTooltip
                  className="borderToggleInfo d-flex flex-column"
                  id="registerTip1"
                  place="right"
                  type="light"
                  effect="solid"
                  clickable={true}
                >
                  <span className="mb-2">Click to get your token</span>
                  <a
                    href="https://support.atlassian.com/atlassian-account/docs/manage-api-tokens-for-your-atlassian-account/"
                    role="button"
                    className="btn btn-md btn-outline-primary"
                    rel="noopener noreferrer"
                    target="_blank"
                  >
                    Jira Token
                  </a>
                </ReactTooltip>
                <input
                  className="LogIn mt-1 mb-2"
                  name="token"
                  id="token"
                  type="text"
                  autoComplete="true"
                  onChange={(e) => this.handleToken(e)}
                />
                <label>Email</label>
                <input
                  className="LogIn mt-1 mb-2"
                  name="email"
                  id="email"
                  type="email"
                  onBlur={(e) => this.handleEmail(e)}
                />
                <label>Password</label>
                <input
                  className="LogIn mt-1 mb-2"
                  name="password"
                  id="password"
                  type="password"
                  autoComplete="true"
                  onChange={(e) => this.handlePassword(e)}
                />

                <div className="d-flex justify-content-start">
                  <input
                    disabled={this.isSubmitting}
                    type="submit"
                    id="btnSesion"
                    value="Sign Up"
                    className="btn btn-block"
                  />
                </div>
              </form>
              <div className="d-flex justify-content-start">
                <Link
                  to="/"
                  id="btnInicio"
                  className="btn btn-md btn-outline-secondary text-left"
                  role="button"
                >
                  Log In
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default SignUp;
