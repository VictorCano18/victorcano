import React, { Component } from "react";
import "./Navbar.css";
import HSBCLogo from "../../assets/img/hsbc.png";
import { Link } from "react-router-dom";

/**
 * Class to create a new Navbar component to navigate among the home page, services pages and user profile.
 * @class Navbar
 */
export default class Navbar extends Component {
  /**
   * Redirects you to the top of the page.
   * @function
   */
  topFunction() {
    document.body.scrollTop = 0; // For Safari
    document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
  }

  /**
   * Deletes the jwt variable that contains the user's token and redirects the user to the main page.
   * @function
   */
  logOut() {
    window.localStorage.removeItem("jwt");
    window.location.href = "./";
    this.topFunction();
  }

  render() {
    /**
     * Returns the HTML to render the Navbar component.
     * @return {class} Navbar
     */
    return (
      <div className="navbar-wrapper">
        <div className="container">
          <nav className="navbar navbar-expand-sm navbar-dark fixed-top">
            <button
              className="navbar-toggler"
              type="button"
              data-toggle="collapse"
              data-target="#navbarMenu"
              aria-controls="navbarSupportNavbaredContent"
              aria-expanded="true"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon"></span>
            </button>
            <a className="navbar-brand" href="/home">
              <img
                src={HSBCLogo}
                id="navbarLogo"
                className="img-fluid"
                alt="HSBCLogo"
              />
            </a>
            <div className="collapse navbar-collapse" id="navbarMenu">
              <ul className="navbar-nav mr-auto align-items-center">
                <li id="nav-home" className="nav-item mr-3">
                  <Link
                    to="/home"
                    className="nav-link"
                    onClick={this.topFunction}
                  >
                    Boards <i id="icons" className="fas fa-table ml-2"></i>
                  </Link>
                </li>
                <li id="nav-graphs" className="nav-item mr-3">
                  <Link
                    to="/productivity"
                    className="nav-link"
                    onClick={this.topFunction}
                  >
                    Productivity
                    <i id="icons" className="far fa-chart-bar ml-2"></i>
                  </Link>
                </li>
                <li id="nav-user" className="nav-item mr-3 d-block d-sm-none">
                  <Link to="/" className="nav-link" onClick={this.logOut}>
                    Log Out
                    <i id="icons" className="fas fa-sign-out-alt ml-2"></i>
                  </Link>
                </li>
              </ul>
              <div id="userProfile" className="d-none d-sm-flex">
                <button
                  id="bLogOut"
                  className="btn btn-md btn-outline-danger"
                  onClick={this.logOut}
                >
                  Log Out
                </button>
              </div>
            </div>
          </nav>
        </div>
      </div>
    );
  }
}
