import React, { useEffect, useContext } from "react";
import "./Charts.css";
import { ResponsiveBar } from "@nivo/bar";
import { UserContext } from "../../context/UserContext";
import { useHistory } from "react-router-dom";
import ErrorIcon from "../../assets/img/error.png";

/**
 * Constant to create a new CardStaffPolicies component.
 * @type {Component}
 */
const Charts = () => {
  /**
   * History variable to navigate among different routes.
   * @let
   */
  let history = useHistory();

  /**
   * Context Constant to use the UserContext in the component to set the charts with the previous data from the
   * boards page.
   * @type {array}
   */
  const { productivity, keys } = useContext(UserContext);

  /**
   * Redirects to the home page to go to the boards.
   * @function
   */
  const goToBoards = () => {
    history.push("/home");
  };

  /**
   * Returns the HTML to render the Charts component.
   * @return {const} Charts
   */
  try {
    return (
      <div className="container">
        <div className="row">
          <div id="barChart" className="col-12">
            <div className="col-12 text-center">
              <strong>Story Points by User</strong>
            </div>
            <ResponsiveBar
              data={productivity.data}
              keys={keys}
              indexBy="Display Name"
              margin={{ top: 50, right: 130, bottom: 50, left: 60 }}
              padding={0.3}
              valueScale={{ type: "linear" }}
              indexScale={{ type: "band", round: true }}
              colors={{ scheme: "red_yellow_blue" }}
              borderColor={{ from: "color", modifiers: [["darker", 1.6]] }}
              colorBy="indexValue"
              axisTop={null}
              axisRight={null}
              axisBottom={{
                tickSize: 5,
                tickPadding: 5,
                tickRotation: 0,
                legend: "User",
                legendPosition: "middle",
                legendOffset: 32,
              }}
              axisLeft={{
                tickSize: 5,
                tickPadding: 5,
                tickRotation: 0,
                legend: "Story Points",
                legendPosition: "middle",
                legendOffset: -40,
              }}
              labelSkipWidth={12}
              labelSkipHeight={12}
              labelTextColor={{
                from: "indexValue",
                modifiers: [["darker", 1.6]],
              }}
              legends={[
                {
                  dataFrom: "keys",
                  anchor: "bottom-right",
                  direction: "column",
                  justify: false,
                  translateX: 120,
                  translateY: 0,
                  itemsSpacing: 2,
                  itemWidth: 100,
                  itemHeight: 20,
                  itemDirection: "right-to-left",
                  itemOpacity: 0.85,
                  symbolSize: 20,
                  effects: [
                    {
                      on: "hover",
                      style: {
                        itemOpacity: 1,
                      },
                    },
                  ],
                },
              ]}
              role="application"
              ariaLabel="Chart 1"
              barAriaLabel={function (e) {
                return (
                  e.id + ": " + e.formattedValue + " user: " + e.indexValue
                );
              }}
            />
          </div>

          {productivity.data.map((issue, id) => (
            <div key={id} id="barChart" className="col-6 col-sm-4">
              <div className="col-12 text-center">
                <strong>{issue.Key + " " + issue["Display Name"]}</strong>
              </div>
              <ResponsiveBar
                data={issue.Worklog}
                keys={["lines"]}
                indexBy="time"
                margin={{ top: 50, right: 130, bottom: 50, left: 60 }}
                padding={0.3}
                valueScale={{ type: "linear" }}
                indexScale={{ type: "band", round: true }}
                colors={{ scheme: "red_blue" }}
                borderColor={{ from: "color", modifiers: [["darker", 1.6]] }}
                colorBy="indexValue"
                axisTop={null}
                axisRight={null}
                axisBottom={{
                  tickSize: 5,
                  tickPadding: 5,
                  tickRotation: 0,
                  legend: "Time (hours)",
                  legendPosition: "middle",
                  legendOffset: 32,
                }}
                axisLeft={{
                  tickSize: 5,
                  tickPadding: 5,
                  tickRotation: 0,
                  legend: "Lines of code",
                  legendPosition: "middle",
                  legendOffset: -40,
                }}
                labelSkipWidth={12}
                labelSkipHeight={12}
                labelTextColor={{
                  from: "indexValue",
                  modifiers: [["darker", 1.6]],
                }}
                legends={[
                  {
                    dataFrom: "keys",
                    anchor: "bottom-right",
                    direction: "column",
                    justify: false,
                    translateX: 120,
                    translateY: 0,
                    itemsSpacing: 2,
                    itemWidth: 100,
                    itemHeight: 20,
                    itemDirection: "right-to-left",
                    itemOpacity: 0.85,
                    symbolSize: 20,
                    effects: [
                      {
                        on: "hover",
                        style: {
                          itemOpacity: 1,
                        },
                      },
                    ],
                  },
                ]}
                role="application"
                ariaLabel="Chart 2"
                barAriaLabel={function (e) {
                  return (
                    e.id + ": " + e.formattedValue + " user: " + e.indexValue
                  );
                }}
              />
            </div>
          ))}
        </div>
      </div>
    );
  } catch (error) {
    return (
      <div className="container">
        <div className="row d-flex justify-content-center align-items-center mt-5 mt-sm-2">
          <div
            id="error"
            className="col-10 d-flex flex-column text-center justify-content-center align-items-center"
          >
            <h1>No data found to load</h1>
            <h2>Select a board and try again</h2>
            <img
              src={ErrorIcon}
              alt="errorIcon"
              id="errorIcon"
              className="img-fluid"
            ></img>
            <button
              id="btnGoBack"
              className="btn btn-danger btn-lg mt-2"
              onClick={(e) => goToBoards(e)}
            >
              Go back
            </button>
          </div>
        </div>
      </div>
    );
  }
};

export default Charts;
