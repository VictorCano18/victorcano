import React, { createContext, useState } from "react";

export const UserContext = createContext({});

export const UserProvider = ({ children }) => {
  const [productivity, setProductivity] = useState([]);
  const [keys, setKeys] = useState([]);

  return (
    <UserContext.Provider
      value={{
        productivity,
        setProductivity,
        keys,
        setKeys
      }}
    >
      {children}
    </UserContext.Provider>
  );
};
